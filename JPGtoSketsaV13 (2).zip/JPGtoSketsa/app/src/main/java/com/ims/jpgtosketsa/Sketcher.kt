package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

class SketchParams(
    val mode: Int,    // 0 pensil hitam-putih, 1 pensil berwarna, 2 garis tegas, 3 pensil arsir
    val blur: Int,    // 0..100 ketebalan/kehalusan garis
    val dark: Int,    // 0..100 kegelapan / kekuatan garis
    val color: Int,   // 0..100 kekuatan warna (mode 1)
    val grain: Int,   // 0..100 tekstur kertas
    val paper: Int    // 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)
)

object Sketcher {
    fun render(src: Bitmap, p: SketchParams): Bitmap {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val scale = max(w, h) / 900f
        val gray = IntArray(n) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        val v = IntArray(n)

        if (p.mode == 3) {
            hatch(gray, w, h, p, scale, v)
        } else if (p.mode == 2) {
            java.util.Arrays.fill(v, 255)
            val g = gray.copyOf()
            boxBlur(g, w, h, max(1, ((1f + p.blur * 0.12f) * scale).roundToInt()))
            val gain = 1.5f + p.dark * 0.06f
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
                val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
                v[i] = 255 - min(255, ((abs(gx) + abs(gy)) * gain / 2f).toInt())
            }
        } else {
            // Color dodge: gambar / (kebalikan gambar yang di-blur)
            val inv = IntArray(n) { 255 - gray[it] }
            boxBlur(inv, w, h, max(1, ((2f + p.blur * 0.38f) * scale).roundToInt()))
            val gamma = 0.6 + p.dark / 100.0 * 1.4
            val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma)).roundToInt().coerceIn(0, 255) }
            for (i in 0 until n) {
                val d = 256 - inv[i]
                v[i] = lut[min(255, gray[i] * 256 / max(1, d))]
            }
        }

        val out = IntArray(n)
        val colored = p.mode == 1
        val kc = p.color / 100f
        val gr = p.grain / 100f
        val pr: Float
        val pg: Float
        val pb: Float
        when (p.paper) {
            1 -> { pr = 245f; pg = 236f; pb = 215f }
            else -> { pr = 255f; pg = 255f; pb = 255f }
        }
        for (i in 0 until n) {
            val noise = ((i * -1640531535) ushr 24) / 255f
            val vv = v[i] * (1f - gr * 0.25f * noise)
            var lr = 255f
            var lg = 255f
            var lb = 255f
            if (colored) {
                val c = px[i]
                lr = 255f * (1f - kc) + Color.red(c) * kc
                lg = 255f * (1f - kc) + Color.green(c) * kc
                lb = 255f * (1f - kc) + Color.blue(c) * kc
            }
            if (p.paper == 3) {
                val al = (255f - vv).toInt().coerceIn(0, 255)
                out[i] = if (colored) Color.argb(al, (lr * 0.5f).toInt().coerceIn(0, 255), (lg * 0.5f).toInt().coerceIn(0, 255), (lb * 0.5f).toInt().coerceIn(0, 255))
                else Color.argb(al, 20, 20, 24)
                continue
            }
            val r: Float
            val g: Float
            val b: Float
            if (p.paper == 2) {
                val t = (255f - vv) / 255f
                r = 43f + (lr - 43f) * t
                g = 58f + (lg - 58f) * t
                b = 51f + (lb - 51f) * t
            } else {
                r = vv * lr / 255f * pr / 255f
                g = vv * lg / 255f * pg / 255f
                b = vv * lb / 255f * pb / 255f
            }
            out[i] = Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Pensil arsir: goresan searah bentuk (LIC), nada halus, kontur tipis, tepi dipudarkan. */
    private fun hatch(gray: IntArray, w: Int, h: Int, p: SketchParams, scale: Float, v: IntArray) {
        val n = w * h
        val tone = gray.copyOf()
        boxBlur(tone, w, h, max(1, (1.2f * scale).roundToInt()))

        // Regangan kontras (persentil 1% - 99%)
        val hist = IntArray(256)
        for (i in 0 until n) hist[tone[i].coerceIn(0, 255)]++
        var lo = 0
        var acc = 0
        while (lo < 255 && acc + hist[lo] < n * 0.01f) { acc += hist[lo]; lo++ }
        var hi = 255
        acc = 0
        while (hi > 0 && acc + hist[hi] < n * 0.01f) { acc += hist[hi]; hi-- }
        if (hi - lo < 32) { lo = 0; hi = 255 }
        val inv = 1f / (hi - lo)
        val gamma = 1f / (0.7f + p.dark / 100f * 1.1f)

        val dir = flowField(tone, w, h, scale)

        // Noise dasar: lebar sel = ketebalan goresan
        val cell = max(1, ((0.8f + p.blur * 0.012f) * scale).roundToInt())
        val noise = FloatArray(n)
        for (y in 0 until h) for (x in 0 until w) noise[y * w + x] = rnd((y / cell) * 100003 + (x / cell))

        val steps = 9
        val stp = max(1f, scale)
        for (y in 0 until h) {
            val fy = (y - h * 0.45f) / (h * 0.65f)
            for (x in 0 until w) {
                val i = y * w + x
                val d = (1f - ((tone[i] - lo) * inv).coerceIn(0f, 1f)).pow(gamma)

                // LIC: rata-rata noise sepanjang arah goresan
                val dx = dir[2 * i] * stp
                val dy = dir[2 * i + 1] * stp
                var s = noise[i]
                for (k in 1..steps) {
                    val ox = dx * k
                    val oy = dy * k
                    s += noise[(y + oy + 0.5f).toInt().coerceIn(0, h - 1) * w + (x + ox + 0.5f).toInt().coerceIn(0, w - 1)]
                    s += noise[(y - oy + 0.5f).toInt().coerceIn(0, h - 1) * w + (x - ox + 0.5f).toInt().coerceIn(0, w - 1)]
                }
                val lic = s / (2 * steps + 1)
                val hv = (0.5f + (lic - 0.5f) * 3.2f).coerceIn(0f, 1f)
                val cov = ((d - hv) / 0.55f + 0.5f).coerceIn(0f, 1f)
                var dark = 0.62f * d + 0.45f * cov * (0.35f + 0.65f * d)

                // Kontur tipis (mata, bibir, tepi kain)
                if (x in 1 until w - 1 && y in 1 until h - 1) {
                    val gx = tone[i + 1] - tone[i - 1]
                    val gy = tone[i + w] - tone[i - w]
                    val e = (((abs(gx) + abs(gy)) * scale - 16f) / 70f).coerceIn(0f, 1f)
                    dark = max(dark, e * 0.45f)
                }

                // Tepi gambar dipudarkan
                val fx = (x - w * 0.5f) / (w * 0.65f)
                val r2 = fx * fx + fy * fy
                dark *= 1f - 0.35f * ((r2 - 0.45f) / 0.9f).coerceIn(0f, 1f)

                v[i] = (255f * (1f - dark * 0.94f)).toInt().coerceIn(0, 255)
            }
        }
    }

    /** Arah goresan per piksel (cos, sin berselang-seling): sejajar tepi, diagonal di area datar. */
    private fun flowField(t: IntArray, w: Int, h: Int, scale: Float): FloatArray {
        val n = w * h
        val jxx = IntArray(n)
        val jyy = IntArray(n)
        val jxy = IntArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = t[i + 1] - t[i - 1]
            val gy = t[i + w] - t[i - w]
            jxx[i] = gx * gx; jyy[i] = gy * gy; jxy[i] = gx * gy
        }
        val r = max(2, (3f * scale).roundToInt())
        boxBlur(jxx, w, h, r); boxBlur(jyy, w, h, r); boxBlur(jxy, w, h, r)
        val out = FloatArray(2 * n)
        for (i in 0 until n) {
            val ax = (jxx[i] - jyy[i]).toFloat()
            val ay = 2f * jxy[i]
            val tr = jxx[i] + jyy[i] + 300f
            val ang = 0.5f * atan2(-ay / tr - 0.45f, -ax / tr)
            out[2 * i] = cos(ang)
            out[2 * i + 1] = sin(ang)
        }
        return out
    }

    private fun rnd(seed: Int): Float {
        var x = seed * -1640531535 + 0x2545F491
        x = x xor (x ushr 15); x *= 0x85ebca6b.toInt()
        x = x xor (x ushr 13); x *= 0xc2b2ae35.toInt()
        x = x xor (x ushr 16)
        return (x ushr 8) / 16777216f
    }

    /** Blur kotak 3x (mendekati Gaussian), tepi di-clamp. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val k = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(tmp, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    tmp[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = tmp[y]
            }
        }
    }
}
