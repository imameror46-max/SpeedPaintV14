plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ims.jpgtosketsa"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ims.jpgtosketsa"
        minSdk = 29
        targetSdk = 34
        versionCode = 8
        versionName = "2.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // Penghapus latar belakang (langkah 2): berjalan di HP lewat Google Play services
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
